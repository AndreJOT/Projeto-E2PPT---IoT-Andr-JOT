// ===============================
// Bibliotecas
// ===============================
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ===============================
// DISPLAY
// ===============================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ===============================
// PINOS
// ===============================
#define POT_PIN 34
#define BTN1 18
#define BTN2 19

// ===============================
// WIFI
// ===============================
const char* ssid = "****";
const char* password = "****";

// ===============================
// MQTT
// ===============================
const char* mqtt_server = "129.153.95.201";
const int mqtt_port = 1883;
const char* mqtt_topic = "****";
const char* mqtt_topic_botao = "****";
const char* client_id = "ESP32_CLIENT";

// ===============================
// OBJETOS
// ===============================
WiFiClient espClient;
PubSubClient client(espClient);

// ===============================
// VARIÁVEIS
// ===============================
int potValue = 0;
int VAL = 0;

int modo = 1;

bool congelado = false;
bool controleMQTT = true;

int valorCongelado = 0;

// ===============================
// DEBOUNCE BOTÕES
// ===============================
unsigned long lastDebounceTime1 = 0;
unsigned long lastDebounceTime2 = 0;

const int debounceDelay = 50;

bool lastReadingBTN1 = LOW;
bool lastReadingBTN2 = LOW;

bool estadoBTN1 = LOW;
bool estadoBTN2 = LOW;

// ===============================
// CALLBACK MQTT
// ===============================
void callback(char* topic, byte* payload, unsigned int length) {

  String mensagem = "";

  for (int i = 0; i < length; i++) {
    mensagem += (char)payload[i];
  }

  if (String(topic) == mqtt_topic_botao) {

    if (mensagem == "1") {
      controleMQTT = true;
    } 
    else if (mensagem == "0") {
      controleMQTT = false;
      valorCongelado = potValue;
    }
  }
}

// ===============================
// WIFI
// ===============================
void conectarWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

// ===============================
// MQTT
// ===============================
void conectarMQTT() {
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  while (!client.connected()) {
    if (client.connect(client_id)) {
      client.subscribe(mqtt_topic_botao);
    } else {
      delay(2000);
    }
  }
}

// ===============================
// PUBLICAR
// ===============================
void publicarValor() {
  char msg[10];
  sprintf(msg, "%d", VAL);
  client.publish(mqtt_topic, msg);
}

// ===============================
// LEITURA BOTÕES (PROFISSIONAL)
// ===============================
void lerBotoes() {

  bool leitura1 = digitalRead(BTN1);
  bool leitura2 = digitalRead(BTN2);

  // ===== BTN1 =====
  if (leitura1 != lastReadingBTN1) {
    lastDebounceTime1 = millis();
  }

  if ((millis() - lastDebounceTime1) > debounceDelay) {

    if (leitura1 != estadoBTN1) {
      estadoBTN1 = leitura1;

      // 🔥 BORDA DE SUBIDA
      if (estadoBTN1 == HIGH) {
        congelado = !congelado;

        if (congelado) {
          valorCongelado = potValue;
        }
      }
    }
  }

  lastReadingBTN1 = leitura1;

  // ===== BTN2 =====
  if (leitura2 != lastReadingBTN2) {
    lastDebounceTime2 = millis();
  }

  if ((millis() - lastDebounceTime2) > debounceDelay) {

    if (leitura2 != estadoBTN2) {
      estadoBTN2 = leitura2;

      if (estadoBTN2 == HIGH) {
        if (!congelado && controleMQTT) {
          modo = (modo == 1) ? 2 : 1;
        }
      }
    }
  }

  lastReadingBTN2 = leitura2;
}

// ===============================
// POT
// ===============================
void lerPotenciometro() {

  bool pausado = congelado || !controleMQTT;

  if (pausado) {
    potValue = valorCongelado;
    return;
  }

  potValue = analogRead(POT_PIN);
  valorCongelado = potValue;
}

// ===============================
// CÁLCULO
// ===============================
void calcularResultado() {

  if (modo == 1) {
    VAL = (potValue * 50) / 4095;
  } else {
    VAL = (potValue * 100) / 4095;
  }

  if (VAL > 100) VAL = 100;
  if (VAL < 0) VAL = 0;
}

// ===============================
// DISPLAY
// ===============================
void atualizarDisplay() {

  bool pausado = congelado || !controleMQTT;

  display.clearDisplay();

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("% MOTOR:");

  display.setTextSize(3);
  display.setCursor(0, 15);
  display.println(VAL);

  display.setTextSize(1);
  display.setCursor(0, 50);
  display.print("MODO: ");
  display.print(modo);
  display.print("X");

  if (pausado) {
    display.setCursor(80, 0);
    display.print("HOLD");
  }

  display.display();
}

// ===============================
// SETUP
// ===============================
void setup() {
  Serial.begin(115200);

  pinMode(BTN1, INPUT_PULLDOWN);
  pinMode(BTN2, INPUT_PULLDOWN);

  analogReadResolution(12);

  Wire.begin(21, 22);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(WHITE);

  conectarWiFi();
  conectarMQTT();
}

// ===============================
// LOOP (SUPER RÁPIDO)
// ===============================
void loop() {

  if (!client.connected()) conectarMQTT();
  client.loop();

  lerBotoes();
  lerPotenciometro();
  calcularResultado();

  static unsigned long last = 0;

  if (millis() - last > 300) {
    last = millis();

    atualizarDisplay();
    publicarValor();
  }
}